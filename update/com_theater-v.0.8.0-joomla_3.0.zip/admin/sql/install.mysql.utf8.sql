SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `#__theater_charts` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `contentid` int(6) NOT NULL,
  `impression` int(2) NOT NULL,
  `critc` int(2) NOT NULL,
  `special` int(2) NOT NULL,
  `gesamt` double NOT NULL,
  `quality` double NOT NULL,
  `hitspoints` double NOT NULL,
  `commentpoints` double NOT NULL,
  `weekpoints` double NOT NULL,
  `checked_out` int(11) NOT NULL,
  PRIMARY KEY (`id`,`contentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

CREATE TABLE IF NOT EXISTS `#__theater_dates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(80) DEFAULT NULL,
  `dates` date NOT NULL DEFAULT '0000-00-00',
  `times` time NOT NULL DEFAULT '00:00:00',
  `supply` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `depart` varchar(80) DEFAULT NULL,
  `info` varchar(80) DEFAULT NULL,
  `critic2` varchar(80) DEFAULT NULL,
  `locid` int(11) NOT NULL DEFAULT '0',
  `criid` int(11) NOT NULL DEFAULT '0',
  `ediid` int(11) NOT NULL DEFAULT '0',
  `author` varchar(80) DEFAULT NULL,
  `director` varchar(80) DEFAULT NULL,
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `content_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

CREATE TABLE IF NOT EXISTS `#__theater_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `city` varchar(60) DEFAULT NULL,
  `code` varchar(5) DEFAULT NULL,
  `street` varchar(40) DEFAULT NULL,
  `number` varchar(10) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `web` varchar(80) DEFAULT NULL,
  `info` text,
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=0 ;

CREATE TABLE IF NOT EXISTS `#__theater_persons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(80) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `info` text,
  `critic` tinyint(1) NOT NULL DEFAULT '0',
  `editor` tinyint(1) NOT NULL DEFAULT '0',
  `author` tinyint(1) NOT NULL DEFAULT '0',
  `director` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=167 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
