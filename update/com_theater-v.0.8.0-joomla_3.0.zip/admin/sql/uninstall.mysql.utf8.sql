DROP TABLE IF EXISTS `#__theater_dates`;
DROP TABLE IF EXISTS `#__theater_location`;
DROP TABLE IF EXISTS `#__theater_person`;
DROP TABLE IF EXISTS `#__theater_chart`;