<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.helper');
JFormHelper::loadFieldClass('list');
 
class JFormFieldPersons extends JFormFieldList {
 
        protected $type = 'persons';
 
        // getLabel() left out
 
        public function getOptions() {
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('tp.id, user.name');
		

		// From the theater_location table
		$query->from('#__theater_persons as tp');
		$query->join('left','#__users as user on(tp.uid = user.id) ');
		$query->where('critic = 1 and published=1');
		// $this->id
		// $this->name
		$query->order('name ASC');
		$db->setQuery((string)$query);
			$sample = $db->loadObjectList();
			$options = array();
			if ($sample)
			{
			foreach($sample as $item) 
			{
			$options[] = JHtml::_('select.option', $item->id, $item->name);
			}
			}
			$options = array_merge(parent::getOptions(), $options);
			// var_dump($options);
			return $options;
			
        }
}
?>