<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.form.formfield');
 
class JFormFieldTime extends JFormField {
 
        protected $type = 'time';
 
        // getLabel() left out
 
        public function getInput() {
			$value = explode(':',$this->value);
		
			for($i = 0;$i<24;$i++){
				$sel = $value[0] == $i?'selected = "selected"':';';
				$h[] = '<option '.$sel.' value="'.($i<10?'0'.$i:$i).'">'.($i<10?'0'.$i:$i).'</option>';
			}
			for($i = 0;$i<60;$i+=5){
				$sel = $value[1] == $i?'selected = "selected"':';';
				$m[] = '<option '.$sel.' value="'.($i<10?'0'.$i:$i).'">'.($i<10?'0'.$i:$i).'</option>';
			}
			// var_dump($this);
		// $this->id
		// $this->name
                return '<input type="hidden" class="in_time" name="'.$this->name.'" id="'.$this->id.'" /><select id="'.$this->id.'_h" style="width:50px" >'.implode("\n",$h).'</select><b style="padding:10px;position:relative;bottom:8px">:</b>'.'<select id="'.$this->id.'_m" style="width:50px">'.implode("\n",$m).'</select>';
        }
}
?>