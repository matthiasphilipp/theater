<?php
/*------------------------------------------------------------------------
# charts.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import the Joomla modellist library
// jimport('joomla.application.component.modellist');
jimport('joomla.application.component.modelitem');
/**
 * Charts Model
 */
class TheaterModelcharts extends JModelItem
{
	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return	string	An SQL query
	 */
	protected $_total;
	protected $_pagination;
	protected $_limitstart;
	protected $_limit;
	
	 function __construct()
	 {
		parent::__construct();
		$this->_limit = 20;
		$this->_limitstart = JRequest::getInt('limitstart',0);
	 }
	 public function getPagination() {
    // Lets load the content if it doesn't already exist
    if (empty($this->_pagination)) {
        $this->_pagination = new JPagination($this->_total, $this->_limitstart,$this->_limit);
    }
		return $this->_pagination;
	}
	 function getItems()
	{
		$this->_limit = 20;
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__theater_charts');
		// $query->where('critic = 1 and published=1');
		// $query->order('name ASC');
		$db->setQuery((string)$query);
		$items = $db->loadObjectList();
		
		$this->_total = count($items);
		var_dump($this->getPagination());
		
		$contents = array();
		$dates = array();
		$res_items = array();
		$_contents = $this->getJContent();
		$_dates = $this->getDates();
		
		// prepare Daten
		foreach($_dates as $d ){
				$dates[date('d.m.Y',strtotime($d->dates))][] = $d;
		}
		foreach($_contents as $c){
			$contents[$c->id] = $c; 
		}
		
		// mit den Items Koppeln
		
		foreach($items as $item){
			$h_content = $contents[$item->id];
			$h_dates = $dates[date('d.m.Y',strtotime($h_content->publish_up))];
			if(count($h_content) && count($h_dates) ){
			foreach($h_dates as $d){
			$res = '';
				if(strpos($h_content->title,$d->title)!== false){
					$res = $d;
					break;
				}
			}	
			}
			
			$res_items[strtotime($item->dates.' '.$item->times).' '.$item->id] = array('content'=>$h_content, 'dates'=>$res, 'charts'=>$item); 
		}
		ksort($res_items);
		$this->_pagination = new JPagination($this->_total, $this->_limitstart,$this->_limit);
		return array_slice($res_items,$this->_limitstart,$this->_limit);
		
	}
	
private function getDates(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('*');
		$query->from('#__theater_dates as jtd');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}	
	private function getJContent(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select(' jc . * , (SELECT count( * ) FROM nac315_jcomments WHERE object_id = jc.id) comments');
		$query->from('#__content jc');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}	
	private function getComments(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		$query->select('tp.id, user.name');
		$query->from('#__theater_persons as tp');
		$query->join('left','#__users as user on(tp.uid = user.id) ');
		$query->where('critic = 1 and published=1');
		$query->order('name ASC');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}	
	 
	/*
	protected function getListQuery()
	{
		// Create a new query object.
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		// $q = "SELECT jtl.name theater, jtd.author, jtd.locid, jtd.dates, jtd.director , jc.title, jc.id, jc.hits, jtd.published,(SELECT count(*) FROM `#__jcomments` where contentid=jc.id) comments,jtch.impression,jtch.id chartid,jtch.critc critic,jtch.special
// FROM #__theater_charts jtch right join (#__theater_dates jtd 
// INNER JOIN #__theater_locations jtl ON ( jtd.locid = jtl.id )
// INNER JOIN `#__content` jc ON ( year( jc.publish_up ) = year( jtd.dates )
// AND month( jc.publish_up ) = month( jtd.dates )
// AND day( jc.publish_up ) = day( jtd.dates ) ) ) on(jtch.contentid=jc.id)
// WHERE jc.title LIKE CONCAT( '%', jtd.title, '%' ) and jtd.published = '1'
// AND jc.title NOT LIKE ''";
		// $result = $db->setQuery($q);
				
		$query->select("*");
		$query->from('#__theater_charts');
		return $query;
	}
	*/
}
?>