/**
 *	dates : Validate
 *	Filename : dates.js
 *
 *	Author : M. Philipp
 *	Component : Theater
 *
 *	Copyright : Copyright (C) 2013. All Rights Reserved
 *	License : GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 *
 **/
window.addEvent('domready', function() {
	if(jQuery('.in_time').size())
	{
		jQuery('.in_time').each(function()
		{
			var $t = jQuery(this);
			console.log($t);
			var id = $t.attr('id');
			jQuery('#'+id+'_h, #'+id+'_m').change(function(){
				$t.val(jQuery('#'+id+'_h').val()+':'+jQuery('#'+id+'_m').val());
			}).change();
		})
	}
});