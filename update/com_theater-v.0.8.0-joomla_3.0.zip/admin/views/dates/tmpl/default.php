<?php
/*------------------------------------------------------------------------
# edit.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');
JHtml::_('formbehavior.chosen', 'select');
JHtml::_('behavior.keepalive');
$params = $this->form->getFieldsets('params');
$fieldsets = ['details', 'published'];
?>
<ul class="nav nav-tabs hidden" >
	<li class="active"><a data-toggle="tab" href="#home">tab</a></li>
</ul>
<form action="<?php echo JRoute::_('index.php?option=com_theater&layout=edit&id='.(int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
	<div class="row-fluid">
	<?
	foreach($fieldsets as $fieldname)
	{
	 $spans = (count($fieldsets)>1?'span6':'span12');
	?>
			<div class="<?=$spans?> form-horizontal">
			<fieldset class="adminform">
				<legend><?php echo JText::_( $fieldname ); ?></legend>
				<div class="adminformlist">
					<?php foreach($this->form->getFieldset($fieldname) as $field){ ?>
						<div>
							<?php echo $field->label; echo $field->input;?>
						</div>
						<div class="clearfix"></div>
					<?php }; ?>
				</div>
			</fieldset>
		</div>
	<?
	}
	
	?>

	</div>
	<div>
		<input type="hidden" name="task" value="dates.edit" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>