<?php
/*------------------------------------------------------------------------
# view.html.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * charts View
 */
class TheaterViewcharts extends JViewLegacy
{
	/**
	 * Charts view display method
	 * @return void
	 */
	function display($tpl = null) 
	{
		// Include helper submenu
		TheaterHelper::addSubmenu('charts');

		// Get data from the model
		$items = $this->get('Items');
		$pagination = $this->get('Pagination');
		
		// Check for errors.
		if (count($errors = $this->get('Errors'))){
			JError::raiseError(500, implode('<br />', $errors));
			return false;
		};
		$this->items = $items;
		$this->pagination = $pagination;

		// Set the toolbar
		$this->addToolBar();
		// Show sidebar
		$this->sidebar = JHtmlSidebar::render();

		// Display the template
		parent::display($tpl);

		// Set the document
		$this->setDocument();
	}
	private function getLocations(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('tp.id, user.name');
		$query->from('#__theater_persons as tp');
		$query->join('left','#__users as user on(tp.uid = user.id) ');
		$query->where('critic = 1 and published=1');
		// $this->id
		// $this->name
		$query->order('name ASC');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}
	private function getDates(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('*');
		// $query->from('#__content');
		$query->from('#__theater_dates as jtd');
		// $query->join('left',"#__content jc ON ( year( jc.publish_up ) = year( jtd.dates ) AND month( jc.publish_up ) = month( jtd.dates ) AND day( jc.publish_up ) = day( jtd.dates ) )");
		// $query->where("jc.title LIKE CONCAT( '%', jtd.title, '%' )");
		
		// $this->id
		// $this->name
		// $query->order('name ASC');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}	
	private function getJContent(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select(' jc . * , (SELECT count( * ) FROM nac315_jcomments WHERE object_id = jc.id) comments');
		$query->from('#__content jc');
		// $query->from('#__theater_dates as jtd');
		// $query->join('left',"#__content jc ON ( year( jc.publish_up ) = year( jtd.dates ) AND month( jc.publish_up ) = month( jtd.dates ) AND day( jc.publish_up ) = day( jtd.dates ) )");
		// $query->where("jc.title LIKE CONCAT( '%', jtd.title, '%' )");
		
		// $this->id
		// $this->name
		// $query->order('name ASC');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}	
	private function getComments(){
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);

		// Select some fields
		$query->select('tp.id, user.name');
		$query->from('#__theater_persons as tp');
		$query->join('left','#__users as user on(tp.uid = user.id) ');
		$query->where('critic = 1 and published=1');
		// $this->id
		// $this->name
		$query->order('name ASC');
		$db->setQuery((string)$query);
		return $db->loadObjectList();
	}
	/**
	 * Setting the toolbar
	 */
	protected function addToolBar() 
	{
		$canDo = TheaterHelper::getActions();
		JToolBarHelper::title(JText::_('Theater Manager'), 'theater');
		if($canDo->get('core.create')){
			JToolBarHelper::addNew('chart.add', 'JTOOLBAR_NEW');
		};
		if($canDo->get('core.edit')){
			JToolBarHelper::editList('chart.edit', 'JTOOLBAR_EDIT');
		};
		if($canDo->get('core.delete')){
			JToolBarHelper::deleteList('', 'charts.delete', 'JTOOLBAR_DELETE');
		};
		if($canDo->get('core.admin')){
			JToolBarHelper::divider();
			JToolBarHelper::preferences('com_theater');
		};
	}

	/**
	 * Method to set up the document properties
	 *
	 *
	 * @return void
	 */
	protected function setDocument() 
	{
		$document = JFactory::getDocument();
		$document->setTitle(JText::_('Theater Manager - Administrator'));
	}
}
?>