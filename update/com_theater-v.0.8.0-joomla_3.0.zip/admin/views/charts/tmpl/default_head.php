<?php
/*------------------------------------------------------------------------
# default_head.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<tr>
	<th width="5">
		<?php echo JText::_('ID'); ?>
	</th>
	<th width="20">
		<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
	</th>
	<th>
		<?php echo JText::_('Datum'); ?>
	</th>
	<th><?php echo JText::_('Dates'); ?></th>
	<th><?php echo JText::_('Charts_g'); ?></th>
	<th><?php echo JText::_('Charts_b'); ?></th>
	<th><?php echo JText::_('Charts_k'); ?></th>
	<th><?php echo JText::_('Charts_q'); ?></th>
	<th><?php echo JText::_('Charts_hits_pkt'); ?></th>
	<th><?php echo JText::_('Charts_comments_pkt'); ?></th>
	<th><?php echo JText::_('Charts_netto'); ?></th>
	<th><?php echo JText::_('Charts_woche_pkt'); ?></th>
	<th><?php echo JText::_('Charts_gesamt_pkt'); ?></th>
</tr>