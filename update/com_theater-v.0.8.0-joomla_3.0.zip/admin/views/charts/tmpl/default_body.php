<?php
/*------------------------------------------------------------------------
# default_body.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$edit = "index.php?option=com_theater&view=charts&task=chart.edit";
$user = JFactory::getUser();
$userId = $user->get('id');
$factor = array('quality_factor'=>1,'comment_factor'=>1,'hits_factor'=>1,'shrink_factor'=>1);
// var_dump($this->items);
var_dump(count($this->items));

?>
<?php foreach($this->items as $i => $item){
	$canCheckin	= $user->authorise('core.manage', 'com_checkin') || $item->checked_out == $userId || $item->checked_out == 0;
	$userChkOut	= JFactory::getUser($item->checked_out);
	
	$charts['impression']	= !empty($item['charts']->impression)?$item['charts']->impression:' - ';
	$charts['critic']		= !empty($item['charts']->critic)?$item['charts']->critic:' - ';
	$charts['special']		= !empty($item['charts']->special)?$item['charts']->special:' - ';
	$charts['quality'] 		= (intval($item['charts']->impression)+intval($item['charts']->critic)+intval($item['charts']->special))*$faktor['quality_faktor'];
	$charts['hits']			= intval($item['charts']->hits);
	$charts['hitspoints'] 	= intval($item['charts']->hits) * $faktor['hits_faktor'];
	$charts['comments']		= intval($item['content']->comments);
	$charts['commentpoints'] = intval($item['content']->comments)*$faktor['comment_faktor'];
	$charts['weeks'] 		= ceil(abs(time() - strtotime($item['charts']->dates)) / 604800);
	$charts['wochenon'] 	= pow($faktor['shrink_faktor'],$weeks);
	
	?>
	<tr class="row<?php echo $i % 2; ?>">
		<td>
			<?php echo $item->id; ?>
		</td>
		<td>
			<?php echo JHtml::_('grid.id', $i, $item->id); ?>
		</td>
		<td>
			<? print date('d.m.Y',strtotime($item['dates']->dates));
			?>
		</td>
		<td>
			<?
			 print $item['dates']->title;
			?>
			<br />
			<?=$i ?>
		<?php if ($item->checked_out){ ?>
				<?php echo JHtml::_('jgrid.checkedout', $i, $userChkOut->name, $item->checked_out_time, 'charts.', $canCheckin); ?>
			<?php } ?>
		</td>
		<td><?
			 print $charts['impression'];
			?>
		</td>
		<td><?
			 print $charts['critic'];
			?>
		</td>
		<td><?
			 print $charts['special'];
			?>
		</td>
		<td>
		<?
			 print $charts['quality'];
		?>
		</td>
		<td><?=$charts['hits']." / ".number_format($charts['hitspoints'], 2, ',', '.')?></td>
		<td><?=$charts['comments']." / ".number_format($charts['commentpoints'], 2, ',', '.')?></td>
		<td><?=number_format($charts['commentpoints']+$charts['hitspoints']+$charts['quality'], 2, ',', '.')?></td>
		<td><?=$charts['weeks']." / ".($charts['weeks']>0?number_format($charts['wochenon'], 2, ',', '.'):0)?></td>
		<td><?=number_format(($charts['commentpoints']+$charts['hitspoints']+$charts['quality'])*$charts['wochenon'], 2, ',', '.')?></td>
	</tr>
<?php } ?>