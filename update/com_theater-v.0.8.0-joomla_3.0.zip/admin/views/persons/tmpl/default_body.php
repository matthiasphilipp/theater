<?php
/*------------------------------------------------------------------------
# default_body.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$edit = "index.php?option=com_theater&view=persons&task=person.edit";
$editUser = "index.php?option=com_users&task=user.edit";
$user = JFactory::getUser();
$userId = $user->get('id');
?>
<?php foreach($this->items as $i => $item){
	$canCheckin	= $user->authorise('core.manage', 'com_checkin') || $item->checked_out == $userId || $item->checked_out == 0;
	$userChkOut	= JFactory::getUser($item->checked_out);
	$canChange = $user->authorise('core.edit.state', 'com_theater') && $canCheckin;
	?>
	<tr class="row<?php echo $i % 2; ?>">
			<td>
			<?php echo JHtml::_('grid.id', $i, $item->id); ?>
		</td>
					<td style="text-align:center">
				<?php echo JHtml::_('jgrid.published', $item->published, $i, 'person.', $canChange); ?>
		</td>
		
		<td>
			<?php echo '<a href="'.$edit.'&id='.$item->uid.'">'.$item->user_name.'</a>';/*' - (<a href="'.$editUser.'&id='.$item->uid.'">'.JText::_('Edit_User').'</a>)';*/
			 if ($item->checked_out){ ?>
				<?php echo JHtml::_('jgrid.checkedout', $i, $userChkOut->name, $item->checked_out_time, 'persons.', $canCheckin); ?>
			<?php } ?>
		</td>
							<td style="text-align:center">
				<?
				if($canChange){
				$item_help = array('critic',$item->critic); 
				print '<a data-original-title="'.JText::_('tooltipp_aktivieren_'.$item_help[1]).'" class="btn btn-micro '.($item_help[1]?'active':'').' hasTooltip" href="javascript:void(0);" onclick="return listItemTask(\'cb'.$item->id.'\',\''.($item_help[1]?'person.un'.$item_help[0]:'person.'.$item_help[0]).'\')" title=""><i class="icon-'.($item_help[1]?'':'un').'publish"></i></a>';

				}
				?>
		</td>
							<td style="text-align:center">
				<?
				if($canChange){
				$item_help = array('editor',$item->editor); 
				print '<a data-original-title="'.JText::_('tooltipp_aktivieren_'.$item_help[1]).'" class="btn btn-micro '.($item_help[1]?'active':'').' hasTooltip" href="javascript:void(0);" onclick="return listItemTask(\'cb'.$item->id.'\',\''.($item_help[1]?'person.un'.$item_help[0]:'person.'.$item_help[0]).'\')" title=""><i class="icon-'.($item_help[1]?'':'un').'publish"></i></a>';

				}
				?>
		</td>
							<td style="text-align:center">
								<?
				if($canChange){
				$item_help = array('author',$item->author); 
				print '<a data-original-title="'.JText::_('tooltipp_aktivieren_'.$item_help[1]).'" class="btn btn-micro '.($item_help[1]?'active':'').' hasTooltip" href="javascript:void(0);" onclick="return listItemTask(\'cb'.$item->id.'\',\''.($item_help[1]?'person.un'.$item_help[0]:'person.'.$item_help[0]).'\')" title=""><i class="icon-'.($item_help[1]?'':'un').'publish"></i></a>';

				}
				?>
		</td>
							<td style="text-align:center">
								<?
				if($canChange){
				$item_help = array('director',$item->director); 
				print '<a data-original-title="'.JText::_('tooltipp_aktivieren_'.$item_help[1]).'" class="btn btn-micro '.($item_help[1]?'active':'').' hasTooltip" href="javascript:void(0);" onclick="return listItemTask(\'cb'.$item->id.'\',\''.($item_help[1]?'person.un'.$item_help[0]:'person.'.$item_help[0]).'\')" title=""><i class="icon-'.($item_help[1]?'':'un').'publish"></i></a>';

				}
				?>
		</td>
	</tr>
<?php } ?>