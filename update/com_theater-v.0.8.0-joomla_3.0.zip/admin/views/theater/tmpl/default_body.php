<?php
/*------------------------------------------------------------------------
# default_body.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$edit = "index.php?option=com_theater&view=theater&task=dates.edit";
$editLoc = "index.php?option=com_theater&view=locations&task=location.edit";
$editCritic =  "index.php?option=com_theater&view=persons&task=person.edit";
$user = JFactory::getUser();
$userId = $user->get('id');
?>
<?php foreach($this->items as $i => $item){
	$canCheckin	= $user->authorise('core.manage', 'com_checkin') || $item->checked_out == $userId || $item->checked_out == 0;
	$userChkOut	= JFactory::getUser($item->checked_out);
	$canChange = $user->authorise('core.edit.state', 'com_theater') && $canCheckin;
	?>
	<tr class="row<?php echo $i % 2; ?>">
		<td>
			<?php echo JHtml::_('grid.id', $i, $item->id); ?>
		</td>
		<td width="80" style="text-align:center">
		<? /*($item->published?'<i class="icon-checkmark green"></i>':'<i class="icon-cancel-2 red"></i>');*/ ?>
		<?php echo JHtml::_('jgrid.published', $item->published, $i, 'theater.', $canChange); ?>
		</td>
		<td width="70">
			<?php echo date("d.m.Y",strtotime($item->dates)); ?>
		</td>
		<td width="20%">
		<?
			if($item->title !='' && strlen($item->title)>2){
				print '<a href="'.$edit.'&id='.$item->id.'">'.$item->title.'</a><div class="small">';
				if($item->author) print $item->author.' ';
				if($item->director) print '('.JText::_('Director').': '.$item->director.')';
				print '</div>';
			}else{
				print ' - (<a href="'.$edit.'&id='.$item->id.'">'.JText::_(JACTION_EDIT).'</a>)';
			}
		?>
			<?php if ($item->checked_out){ ?>
				<?php echo JHtml::_('jgrid.checkedout', $i, $userChkOut->name, $item->checked_out_time, 'theater.', $canCheckin); ?>
			<?php } ?>
		</td>

		<td width="10%">
			<? if($item->criname!=''){ ?><a href="<?php echo $editCritic; ?>&id=<?php echo $item->criid; ?>"><?php echo $item->criname; ?></a><? }else print ' - '; ?>
		</td>
		<td width="10%">
			<?php echo ($item->critic2?$item->critic2:' - '); ?>
		</td>
		<td width="10%">
			<?php echo ($item->depart?$item->depart:' - '); ?>
		</td>
		<td width="10%">
			<?php echo ($item->info?$item->info:' - '); ?>
		</td>
		<td>
			<?php if($item->location) print '<a href="'.$editLoc.'&id='.$item->locid.'">'.$item->location.'</a>'; else print ' - '; ?>
		</td>
	</tr>
<?php } ?>