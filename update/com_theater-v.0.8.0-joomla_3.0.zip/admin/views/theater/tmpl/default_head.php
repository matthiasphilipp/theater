<?php
/*------------------------------------------------------------------------
# default_head.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<tr>
	<th width="20">
		<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
	</th>
	<th>
	<?php echo JHTML::_('grid.sort', JText::_('Published'),  $this->sortColumn,$this->sortDirection); ?>
	</th>
	<th>
		<?php echo JHTML::_('grid.sort',JText::_('Dates'), $this->sortColumn,$this->sortDirection); ?>
	</th>
	<th>
		<?php echo JHTML::_('grid.sort',JText::_('Title'),  $this->sortColumn,$this->sortDirection); ?>
	</th>

	<th>
		<?php echo JText::_('Criname'); ?>
	</th>
	<th>
		<?php echo JText::_('Criname2'); ?>
	</th>
	<th>
		<?php echo JText::_('Depart'); ?>
	</th>
	<th>
		<?php echo JText::_('Info'); ?>
	</th>
	<th>
		<?php echo JText::_('Location'); ?>
	</th>
</tr>