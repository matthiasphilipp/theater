<?php
/*------------------------------------------------------------------------
# default.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// load tooltip behavior
JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
JHtml::_('dropdown.init');
JHtml::_('formbehavior.chosen', 'select');


?>
<script language="javascript" type="text/javascript">
function tableOrdering( order, dir, task )
{
        var form = document.adminForm;
 
        form.filter_order.value = order;
        form.filter_order_Dir.value = dir;
        document.adminForm.submit( task );
}
</script>
<style>
.red{color:#f00}
.green{color:#51A351}
</style>
<form action="<?php echo JRoute::_('index.php?option=com_theater&view=theater'); ?>" method="post" name="adminForm" id="adminForm">
<?php if(!empty( $this->sidebar)){ ?>
	<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
<?php } else { ?>
	<div id="j-main-container">
<?php }; ?>
<?php echo $this->loadTemplate('filter'); ?>
		<table class="table table-striped">
			<thead><?php echo $this->loadTemplate('head');?></thead>
			<tfoot><?php echo $this->loadTemplate('foot');?></tfoot>
			<tbody><?php echo $this->loadTemplate('body');?></tbody>
		</table>
		<div>
		<input type="hidden" name="task" value=""/>
		<input type="hidden" name="boxchecked" value="0"/>
		<input type="hidden" name="filter_order" value="<?php echo $this->sortColumn; ?>"/>
		<input type="hidden" name="filter_order_Dir" value="<?php echo $this->sortDirection; ?>"/>
			<?php echo JHtml::_('form.token'); ?>
		</div>
	</div>
</form>