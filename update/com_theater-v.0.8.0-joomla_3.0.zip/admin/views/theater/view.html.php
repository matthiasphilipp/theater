<?php
/*------------------------------------------------------------------------
# view.html.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla view library
jimport('joomla.application.component.view');

/**
 * theater View
 */
class TheaterViewtheater extends JViewLegacy
{
	/**
	 * Theater view display method
	 * @return void
	 */
	function display($tpl = null) 
	{
		// Include helper submenu
		TheaterHelper::addSubmenu('theater');

		// Get data from the model
		$items = $this->get('Items');
		$pagination = $this->get('Pagination');
		$state = $this->get('State');
		
		$filter_year = $state->get('filter.year');
		$filter_month = $state->get('filter.month');
		$filter_state = $state->get('filter.state');
		// Filter by published state
		$filter_state_options = array();
		$filter_state_options[] = JHTML::_('select.option', '1', JText::_('A_FILTER_STATE_PUBLISHED'));
		$filter_state_options[] = JHTML::_('select.option', '0', JText::_('A_FILTER_STATE_UNPUBLISHED'));
		
		// Filter by published state
		$filter_month_options = array();
		for($i=1;$i<13;$i++){		
		$filter_month_options[] = JHTML::_('select.option', $i, JText::_('month_long_'.$i));
		}
		$filter_year_options = array();
		for($i=date('Y',strtotime('-5years'));$i<date('Y',strtotime('+2year'));$i++){		
		$filter_year_options[] = JHTML::_('select.option', $i, $i);
		}
		
        $this->sortDirection = $state->get('list.direction');
        $this->sortColumn = $state->get('list.ordering');
		$this->sortFields = $this->getSortFields();
		
		// Check for errors.
		if (count($errors = $this->get('Errors'))){
			JError::raiseError(500, implode('<br />', $errors));
			return false;
		};

		// Assign data to the view
		$this->items = $items;
		$this->pagination = $pagination;

		// Set the toolbar
		$this->addToolBar();
		// Show sidebar
		JHtml::_('formbehavior.chosen', 'select');
		JHtmlSidebar::setAction('index.php?option=com_theater&view=theater');
		
		JHtmlSidebar::addFilter(
				JText::_('A_FILTER_STATE'),
				'filter_state',
				JHtml::_('select.options', $filter_state_options, 'value', 'text', $filter_state, true)
			);
		JHtmlSidebar::addFilter(
				JText::_('A_FILTER_MONTH'),
				'filter_month',
				JHtml::_('select.options', $filter_month_options, 'value', 'text', $filter_month, true)
			);	
		JHtmlSidebar::addFilter(
				JText::_('A_FILTER_YEAR'),
				'filter_year',
				JHtml::_('select.options', $filter_year_options, 'value', 'text', $filter_year, true)
			);	
		$this->sidebar = JHtmlSidebar::render();

		// Display the template
		parent::display($tpl);

		// Set the document
		$this->setDocument();
	}

	/**
	 * Setting the toolbar
	 */
	protected function addToolBar() 
	{
		$canDo = TheaterHelper::getActions();
		JToolBarHelper::title(JText::_('Theater Manager'), 'theater');
		if($canDo->get('core.create')){
			JToolBarHelper::addNew('dates.add', 'JTOOLBAR_NEW');
		};
		if($canDo->get('core.edit')){
			JToolBarHelper::editList('dates.edit', 'JTOOLBAR_EDIT');
		};
		if($canDo->get('core.delete')){
			JToolBarHelper::deleteList('', 'theater.delete', 'JTOOLBAR_DELETE');
		};
		if($canDo->get('core.admin')){
			JToolBarHelper::divider();
			JToolBarHelper::preferences('com_theater');
		};
	}

	/**
	 * Method to set up the document properties
	 *
	 *
	 * @return void
	 */
	protected function setDocument() 
	{
		$document = JFactory::getDocument();
		$document->setTitle(JText::_('Theater Manager - Administrator'));
	}
	
	protected function getSortFields()
	{
		return array(
			'title' => JText::_('Title'),
			'dates' => JText::_('Dates'),
			'published' => JText::_('Published'),
		);
	}
}
?>