<?php
/*------------------------------------------------------------------------
# default_body.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

$edit = "index.php?option=com_theater&view=locations&task=location.edit";
$user = JFactory::getUser();
$userId = $user->get('id');
?>
<?php foreach($this->items as $i => $item){
	$canCheckin	= $user->authorise('core.manage', 'com_checkin') || $item->checked_out == $userId || $item->checked_out == 0;
	$userChkOut	= JFactory::getUser($item->checked_out);
	$canChange = $user->authorise('core.edit.state', 'com_theater') && $canCheckin;
	?>
	<tr class="row<?php echo $i % 2; ?>">
		<td>
			<?php echo JHtml::_('grid.id', $i, $item->id); ?>
		</td>
		<td style="width:80px;text-align:center">
				<?php echo JHtml::_('jgrid.published', $item->published, $i, 'location.', $canChange); ?>
		</td>
		<td>
			<?php 
			if($item->name !=''){
				print '<a href="'.$edit.'&id='.$item->id.'">'.$item->name.'</a><div class="small">';
				if($item->street) print $item->street.', ';
				if($item->code) print $item->code.' ';
				if($item->city) print $item->city;
				if($item->web) print ' (<a href="'.$item->web.'" target="_blank">'.$item->web.'</a>)';
				print '</div>';
			}else{
				print ' - ';
			}
			?>
			<?php if ($item->checked_out){ ?>
				<?php echo JHtml::_('jgrid.checkedout', $i, $userChkOut->name, $item->checked_out_time, 'locations.', $canCheckin); ?>
			<?php } ?>
		</td>
	</tr>
<?php } ?>