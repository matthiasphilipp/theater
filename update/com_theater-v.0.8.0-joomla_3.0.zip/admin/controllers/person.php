<?php
/*------------------------------------------------------------------------
# person.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controllerform library
jimport('joomla.application.component.controllerform');

/**
 * Persons Controller Person
 */
class TheaterControllerperson extends JControllerForm
{
	public function __construct($config = array())
	{
		$this->view_list = 'persons'; // safeguard for setting the return view listing to the main view.
		parent::__construct($config);
		 $this->registerTask('uncritic', 'critic');
		 $this->registerTask('uneditor', 'editor');
		 $this->registerTask('undirector', 'director');
		 $this->registerTask('unauthor', 'author');
	}

	/**
	 * Function that allows child controller access to model data
	 * after the data has been saved.
	 * 
	 * @param   JModel  &$model     The data model object.
	 * @param   array   $validData  The validated data.
	 * 
	 * @return  void
	 * 
	 * @since   11.1
	 */
	protected function postSaveHook(JModelLegacy &$model, $validData = array())
	{
		// Get a handle to the Joomla! application object
		$application = JFactory::getApplication();

		$model->save($data);

	}
	
	public function critic(){
	
		// var_dump('critic');
		
		 $ids = JRequest::getVar('cid', array(), '', 'array'); 
		JArrayHelper::toInteger($ids );
		$cids = implode( ',', $ids); 
		$task = $this->getTask(); 
		$this->saveTaskAndRedirect($task,$cids);
	}	
	
	public function author(){
		 $ids = JRequest::getVar('cid', array(), '', 'array'); 
		JArrayHelper::toInteger($ids );
		$cids = implode( ',', $ids); 
		$task = $this->getTask(); 
		$this->saveTaskAndRedirect($task,$cids);
	}	
	
	public function director(){
			 $ids = JRequest::getVar('cid', array(), '', 'array'); 
		JArrayHelper::toInteger($ids );
		$cids = implode( ',', $ids); 
		$task = $this->getTask(); 
		$this->saveTaskAndRedirect($task,$cids);
	}	
	
	public function editor(){
		$ids = JRequest::getVar('cid', array(), '', 'array'); 
		JArrayHelper::toInteger($ids );
		$cids = implode( ',', $ids); 
		
		$task = $this->getTask(); 
		$this->saveTaskAndRedirect($task,$cids);
	}	

	private function saveTaskAndRedirect($task,$cids)
	{
		// var_dump($cids);
		$db =&JFactory::getDBO();      
		$query = 'UPDATE #__theater_persons' . ' SET '.$task.' = !'.$task.' WHERE id IN ( '.$cids.' )';
		$db->setQuery($query);
		$result = $db->query();
		$redirectTo = JRoute::_('index.php?option='.JRequest::getVar('option').'&view=persons'); 
		// var_dump($redirectTo);
		$this->setRedirect(str_replace('&amp;','&',$redirectTo));
	}

}
?>