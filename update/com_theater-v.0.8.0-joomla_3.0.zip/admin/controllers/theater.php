<?php
/*------------------------------------------------------------------------
# theater.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controlleradmin library
jimport('joomla.application.component.controlleradmin');

/**
 * Theater Controller
 */
class TheaterControllertheater extends JControllerAdmin
{
	/**
	 * Proxy for getModel.
	 * @since	2.5
	 */
	public function getModel($name = 'dates', $prefix = 'TheaterModel')
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));
		
		return $model;
	}
	
	public function publish()
	{
		JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));
		
		$cid = $this->input->get('cid', array(), 'array');
		// var_dump($cid);
		$data = array('publish' => 1, 'unpublish' => 0);
		$task = $this->getTask();
		// var_dump($task);
		$value = JArrayHelper::getValue($data, $task, 0, 'int');
		// var_dump($value);
		if (!empty($cid)) {
			$model = $this->getModel();
			$res = $model->publish($cid, $value);
			// var_dump($res);
		}

		$this->setRedirect(JRoute::_('index.php?option=' . $this->option . '&view=' . $this->view_list, false));
	}
}
?>