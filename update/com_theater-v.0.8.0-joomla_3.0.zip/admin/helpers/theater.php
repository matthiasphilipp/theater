<?php
/*------------------------------------------------------------------------
# theater.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Theater component helper.
 */
abstract class TheaterHelper
{
	/**
	 *	Configure the Linkbar.
	 */
	public static function addSubmenu($submenu) 
	{
		JHtmlSidebar::addEntry(JText::_('Theater'), 'index.php?option=com_theater&view=theater', $submenu == 'theater');
		JHtmlSidebar::addEntry(JText::_('Locations'), 'index.php?option=com_theater&view=locations', $submenu == 'locations');
		JHtmlSidebar::addEntry(JText::_('Persons'), 'index.php?option=com_theater&view=persons', $submenu == 'persons');
		JHtmlSidebar::addEntry(JText::_('Charts'), 'index.php?option=com_theater&view=charts', $submenu == 'charts');
	}

	/**
	 *	Get the actions
	 */
	public static function getActions($Id = 0)
	{
		jimport('joomla.access.access');

		$user	= JFactory::getUser();
		$result	= new JObject;

		if (empty($Id)){
			$assetName = 'com_theater';
		} else {
			$assetName = 'com_theater.message.'.(int) $Id;
		};

		$actions = JAccess::getActions('com_theater', 'component');

		foreach ($actions as $action){
			$result->set($action->name, $user->authorise($action->name, $assetName));
		};

		return $result;
	}
}
?>