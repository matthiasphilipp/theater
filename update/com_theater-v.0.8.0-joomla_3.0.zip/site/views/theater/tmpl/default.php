<?php
/*------------------------------------------------------------------------
# default.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filter.output');
?>
		<script language="javascript" type="text/javascript">
			function addParams(id)
			{
				var link = document.getElementById(id);
				var month = document.getElementById('month').value;
				var year = document.getElementById('year').value;
				var dsort = document.getElementById('dsort').value;
				link.href += '&month=' + month + '&year=' + year + '&sort=' + dsort;
			}
		</script>
<div id="theater-theater">
<?
// var_dump($this->sortfields);
?>
<div align="right">
		<select id="dsort" name="dsort">
		<?
			
			foreach($this->sortfields as $i=>$dsort){
				$sel = $i == $this->dsort?' selected=""':'';
				print '<option value="'.$i.'" '.$sel.'>'.$dsort.'</option>';
			
			}
		?>
	
		</select>
		<select id="month" name="month">
		<?
			for($i= 1;$i<13;$i++){
				$sel = $i == $this->month?' selected=""':'';
				print '<option value="'.$i.'" '.$sel.'>'.JText::_('month_long_'.$i).'</option>';
			
			}
		?>
		</select>
		<select id="year" name="year">
		<option value="2012">2012</option><option selected="" value="2013">2013</option><option value="2014">2014</option></select>
		<br />
		<a id="show" href="index.php/component/theater/?task=showdates&Itemid=98" onclick="addParams('show');">[ Anzeigen ]</a>
</div>

<h3><?=$this->headline?></h3>

		<table border="0" width="80%" cellspacing="2">
	<?php foreach($this->items as $item){ ?>
		<?php
		if(empty($item->alias)){
			$item->alias = $item->title;
		};
		$item->alias = JFilterOutput::stringURLSafe($item->alias);
		$item->linkURL = JRoute::_('index.php?option=com_theater&view=dates&id='.$item->id.':'.$item->alias);

			$oday = 0;

				echo "<tr>\n";
				$date = explode( "-", $item->dates );
				if ( !$this->dsort ) {
					if ( $date[2] > $oday ) {
						echo "<td valign=\"top\">" . $date[2] . "." . $date[1] . ". </td>\n";
						$oday = $date[2];
					} else {
						echo "<td>".""."</td>";
					}
				} else {
					echo "<td valign=\"top\">" . $date[2] . "." . $date[1] . ". </td>\n";
				}
				echo '<td valign="top"><a href ="'.$item->web.'">'.$item->title."</a><br />".$item->location."</td>\n";
				echo "<td valign=\"top\">" . $item->author . ":<br><strong>" .  $item->title . "</strong><br>Regie: " . $item->director. "<br><br></td>\n";
				echo "</tr>\n";
			
		}; 
		
		?>
		</table>
		</div>
	<!--	
		<p><strong>Title</strong>: <a href="<?php echo $item->linkURL; ?>"><?php echo $item->title; ?></a></p>
		<p><strong>Dates</strong>: <?php echo $item->dates; ?></p>
		<p><strong>Times</strong>: <?php echo $item->times; ?></p>
		<p><strong>Supply</strong>: <?php echo $item->supply; ?></p>
		<p><strong>Depart</strong>: <?php echo $item->depart; ?></p>
		<p><strong>Info</strong>: <?php echo $item->info; ?></p>
		<p><strong>Locid</strong>: <?php echo $item->locid; ?></p>
		<p><strong>Criid</strong>: <?php echo $item->criid; ?></p>
		<p><strong>Ediid</strong>: <?php echo $item->ediid; ?></p>
		<p><strong>Author</strong>: <?php echo $item->author; ?></p>
		<p><strong>Director</strong>: <?php echo $item->director; ?></p>
		<p><strong>Checked_out_time</strong>: <?php echo $item->checkedouttime; ?></p>
		<p><strong>Published</strong>: <?php echo $item->published; ?></p>
		<p><strong>Link URL</strong>: <a href="<?php echo $item->linkURL; ?>">Go to page</a> - <?php echo $item->linkURL; ?></p>
		<br /><br />

</div>-->
