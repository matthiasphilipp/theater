<?php
/*------------------------------------------------------------------------
# view.html.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
// import Joomla view library
jimport('joomla.application.component.view');
/**
 * HTML Theater View class for the Theater Component
 */
class TheaterViewtheater extends JViewLegacy
{
	// Overwriting JView display method
	function display($tpl = null)
	{
		
		 $app            = JFactory::getApplication();
         $params         = $app->getParams();
		 
		$month = JRequest::getVar('month',date('m'),'get');
		$year = JRequest::getVar('year',date('Y'),'get');
		$sort = JRequest::getVar('sort',0,'get');
		
		// Assign data to the view
		$this->items = $this->get('Items');
		$this->month = $month;
		$this->year = $year;
		$this->dsort = $sort;
		
		$this->headline = JText::_('month_long_'.$month).' '.$year;
		$this->sortfields = array(
				JText::_('sort_by'),
				JText::_('Dates'),
				JText::_('Theater'),
				JText::_('City'),
				JText::_('Author'),
				JText::_('Director')
				);
		
		// Check for errors.
		if (count($errors = $this->get('Errors'))){
			JError::raiseError(500, implode('<br />', $errors));
			return false;
		};
		// Display the view
		parent::display($tpl);
	}
		protected function getSortFields()
	{
		return array(
			'title' => JText::_('Title'),
			'dates' => JText::_('Dates'),
			'published' => JText::_('Published'),
		);
	}
}
?>