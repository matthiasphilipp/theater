<?php
/*------------------------------------------------------------------------
# default.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<div id="theater-content">
	<p><strong>Title</strong>: <?php echo $this->item->title; ?></p>
	<p><strong>Dates</strong>: <?php echo $this->item->dates; ?></p>
	<p><strong>Times</strong>: <?php echo $this->item->times; ?></p>
	<p><strong>Supply</strong>: <?php echo $this->item->supply; ?></p>
	<p><strong>Depart</strong>: <?php echo $this->item->depart; ?></p>
	<p><strong>Info</strong>: <?php echo $this->item->info; ?></p>
	<p><strong>Locid</strong>: <?php echo $this->item->locid; ?></p>
	<p><strong>Criid</strong>: <?php echo $this->item->criid; ?></p>
	<p><strong>Ediid</strong>: <?php echo $this->item->ediid; ?></p>
	<p><strong>Author</strong>: <?php echo $this->item->author; ?></p>
	<p><strong>Director</strong>: <?php echo $this->item->director; ?></p>
	<p><strong>Checked_out_time</strong>: <?php echo $this->item->checkedouttime; ?></p>
	<p><strong>Published</strong>: <?php echo $this->item->published; ?></p>
</div>