<?php
/*------------------------------------------------------------------------
# default.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filter.output');
?>
<div id="theater-persons">
	<?php foreach($this->items as $item){ ?>
		<?php
		if(empty($item->alias)){
			$item->alias = $item->uid;
		};
		$item->alias = JFilterOutput::stringURLSafe($item->alias);
		$item->linkURL = JRoute::_('index.php?option=com_theater&view=person&id='.$item->id.':'.$item->alias);
		?>
		<p><strong>Uid</strong>: <a href="<?php echo $item->linkURL; ?>"><?php echo $item->uid; ?></a></p>
		<p><strong>Alias</strong>: <?php echo $item->alias; ?></p>
		<p><strong>Link URL</strong>: <a href="<?php echo $item->linkURL; ?>">Go to page</a> - <?php echo $item->linkURL; ?></p>
		<br /><br />
	<?php }; ?>
</div>
