<?php
/*------------------------------------------------------------------------
# default.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<div id="theater-content">
	<p><strong>Name</strong>: <?php echo $this->item->name; ?></p>
	<p><strong>City</strong>: <?php echo $this->item->city; ?></p>
	<p><strong>Code</strong>: <?php echo $this->item->code; ?></p>
	<p><strong>Street</strong>: <?php echo $this->item->street; ?></p>
</div>