<?php
/*------------------------------------------------------------------------
# theater.php - Theater Component
# ------------------------------------------------------------------------
# author    M. Philipp
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   google.de
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
// import the Joomla modellist library
jimport('joomla.application.component.modellist');
/**
 * Theater Model
 */
class TheaterModeltheater extends JModelList
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'title', 'dates' 
			);
		}

		parent::__construct($config);
	}
	/*
	protected function populateState($ordering = null, $direction = null) {
		$app = JFactory::getApplication();
	
        parent::populateState('dates', 'DESC');
	}
	*/
	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return      string  An SQL query
	 */
	 
	protected function getListQuery()
	{
		$month = JRequest::getVar('month',date('m'),'get');
		$year = JRequest::getVar('year',date('Y'),'get');
		$sort = JRequest::getVar('sort',0,'get');
		
		$sortarray = array(
			false,
			'td.dates',
			'location',
			'loc.city',
			'td.title',
			'td.authot',
			'td.director'
		);
		// Create a new query object.
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		// Select some fields
				// Select some fields
		$query->select("td.*,if (loc.name!='',concat(loc.name,' in ',loc.city),'-') as location,loc.web web,user.name as criname");

		// From the theater_dates table
		$query->from('#__theater_dates as td');
		$query->join('left','#__theater_locations as loc on(td.locid = loc.id) ');
		$query->join('left','#__theater_persons as tp on(td.criid = tp.id) ');
		$query->join('left','#__users as user on(tp.uid = user.id) ');

		$year = $year?$year:date('Y');
		if (is_numeric($month)) {
				$query->where('(month(td.dates) = ' .(int) $month.' and year(td.dates) = ' .(int) $year.')');
		}else if(is_numeric($year)){
				$query->where('year(td.dates) = ' .(int) $year);
		}
		$query->where('td.published=1');
		if($sort) $query->order($sortarray[$sort].' ASC');
		else{
			 $query->order('td.dates ASC');
		}
		
		return $query;
	}
}
?>